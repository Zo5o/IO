/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Kuba
 */
@Entity
@Table(name = "BACKPACK")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Backpack.findAll", query = "SELECT b FROM Backpack b"),
    @NamedQuery(name = "Backpack.findById", query = "SELECT b FROM Backpack b WHERE b.id = :id"),
    @NamedQuery(name = "Backpack.findByProductName", query = "SELECT b FROM Backpack b WHERE b.productName = :productName"),
    @NamedQuery(name = "Backpack.findByProductBrand", query = "SELECT b FROM Backpack b WHERE b.productBrand = :productBrand"),
    @NamedQuery(name = "Backpack.findByCapacity", query = "SELECT b FROM Backpack b WHERE b.capacity = :capacity"),
    @NamedQuery(name = "Backpack.findByPrice", query = "SELECT b FROM Backpack b WHERE b.price = :price")})
public class Backpack implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "PRODUCT_NAME")
    private String productName;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "PRODUCT_BRAND")
    private String productBrand;
    @Basic(optional = false)
    @NotNull
    @Column(name = "CAPACITY")
    private int capacity;
    @Basic(optional = false)
    @NotNull
    @Column(name = "PRICE")
    private double price;
    @JoinColumn(name = "PRODUCT_ID", referencedColumnName = "ID")
    @ManyToOne(optional = false)
    private Product productId;

    public Backpack() {
    }

    public Backpack(Integer id) {
        this.id = id;
    }

    public Backpack(Integer id, String productName, String productBrand, int capacity, double price) {
        this.id = id;
        this.productName = productName;
        this.productBrand = productBrand;
        this.capacity = capacity;
        this.price = price;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductBrand() {
        return productBrand;
    }

    public void setProductBrand(String productBrand) {
        this.productBrand = productBrand;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Product getProductId() {
        return productId;
    }

    public void setProductId(Product productId) {
        this.productId = productId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Backpack)) {
            return false;
        }
        Backpack other = (Backpack) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Backpack[ id=" + id + " ]";
    }
    
}
